#Package documentation assignment

#' Read "filename" as dataframe
#'
#' This is a simple function reading in the specified filename as the input data of the function
#' The function output is the data from the filename as a dataframe. The function first checks whether the specified file,
#' exists. If FALSE is returned in the if() statement, the output "file does not exist" is returned by stop.
#'
#' @param filename A character string of the filename the function will use to generate a dataframe out of.
#'
#' @return This function returns a dataframe, generated from the input file.
#'
#' @examples
#' fars_read()
#' fars_read(filename)
#'
#' @export
fars_read <- function(filename) {
  if(!file.exists(filename))
    stop("file '", filename, "' does not exist")
  data <- suppressMessages({
    readr::read_csv(filename, progress = FALSE)
  })
  dplyr::tbl_df(data)
}
#' Make a filename based on the year input
#'
#' This functions has an integer as parameter of a year.
#' This year domain is accesed within the "accident_%d.csv.bz2" file. This is a simple function sprintf is a wrapper for the system sprintf C-library function.
#' Attempts are made to check that the mode of the values passed match the format supplied, and R's special values (NA, Inf, -Inf and NaN) are handled correctly.
#'
#' @param year An integer input of a year from the "accident_%d.csv.bz2" file.
#'
#' @return This function returns a filename, generated from the "accident_%d.csv.bz2" file.
#'
#' @examples
#' make_filename()
#' make_filename(year)
#'
#' @export
make_filename <- function(year) {
  year <- as.integer(year)
  sprintf("accident_%d.csv.bz2", year)
}

#' Fars_read_years returns a list of values
#'
#' This function makes use of the previously defined functions make_filename() and fars_read(),
#' in order to generate a list output of years from the "accident_%d.csv.bz2" data. The tryCatch() function helps in handling unusual conditions or
#' errors by generating a warning and returning NULL when the data is not found.
#'
#' @param years An integer input of the year to be accessed.
#'
#' @return This function returns a list or "NULL" in case an error occurs when an invalid year is entered as input.
#'
#'
#' @examples
#' fars_read_years()
#' fars_read_years(years)
#'
#' @export

fars_read_years <- function(years) {
  lapply(years, function(year) {
    file <- make_filename(year)
    tryCatch({
      dat <- fars_read(file)
      dplyr::mutate(dat, year = year) %>%
        dplyr::select(MONTH, year)
    }, error = function(e) {
      warning("invalid year: ", year)
      return(NULL)
    })
  })
}

#' Summarize "years" into a new dataframe
#'
#' Using multiple functions from the dplyr package such as summarize, bind_rows and group_by; data from the
#' fars_read_years () function is summarized into a new dataframe.
#'
#' @param years An integer value of the year of which the data will be summarized into a new dataframe.
#'
#'
#' @return A new summarized dataframe is generated using this function.
#'
#' @examples
#' fars_summarize_years()
#' fars_summarize_years(years)
#'
#' @export
fars_summarize_years <- function(years) {
  dat_list <- fars_read_years(years)
  dplyr::bind_rows(dat_list) %>%
    dplyr::group_by(year, MONTH) %>%
    dplyr::summarize(n = n()) %>%
    tidyr::spread(year, n)
}

#' Plotting the accidents of a state within a specified year.
#'
#' This function returns a plot of the accidents in a state, which is specified by the state number.
#' In case no accidents were found, the function will return a message with "no accidents to plot'.
#' The accidents are specified in the fars_map_state () function with the parameters state,num and year,
#' this way accidents are plotted of a specific state and year.
#'
#' @param state.num An integer value of the state number.
#'
#' @param year
#'
#' @importFrom graphics points
#'
#' @return This function returns an error if the state number is not found in the state column of the data,
#' in the case accidents had occured, they are plotted and a plot is returned as output.
#'
#' @examples
#' fars_map_state()
#' fars_map_state(state.num)
#' fars_map_state(year=1998)
#'
#' @export
fars_map_state <- function(state.num, year) {
  filename <- make_filename(year)
  data <- fars_read(filename)
  state.num <- as.integer(state.num)

  if(!(state.num %in% unique(data$STATE)))
    stop("invalid STATE number: ", state.num)
  data.sub <- dplyr::filter(data, STATE == state.num)
  if(nrow(data.sub) == 0L) {
    message("no accidents to plot")
    return(invisible(NULL))
  }
  is.na(data.sub$LONGITUD) <- data.sub$LONGITUD > 900
  is.na(data.sub$LATITUDE) <- data.sub$LATITUDE > 90
  with(data.sub, {
    maps::map("state", ylim = range(LATITUDE, na.rm = TRUE),
              xlim = range(LONGITUD, na.rm = TRUE))
    graphics::points(LONGITUD, LATITUDE, pch = 46)
  })
}

