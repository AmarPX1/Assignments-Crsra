library(testthat)
expect_that(fars_read("filename"), expect_output("file filename does not exist"))

